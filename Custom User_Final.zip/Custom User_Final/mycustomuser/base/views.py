from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import User, Case, Criminal
from .forms import UserReg, NewCaseForm, UserProfileEdit, NewCriminal
from django.db import connection
from django.db.models import Q

# Create your views here.
def home(request):
    return render(request, 'base/home.html')

def loginpage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        try:
            user = User.objects.get(username=username)
        except:
            messages.error(request, 'User does not exist')

        user = authenticate(request, username = username, password = password)

        if user is not None:
            login(request, user)
            return redirect('cases')

    return render(request, 'base/login.html')

def logoutuser(request):
    logout(request)
    return redirect('/')

    return render(request, 'base/login.html')

def registerpage(request):
    form = UserReg()

    if request.method == 'POST':
        form = UserReg(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')

    context = {
        'form': form
    }

    return render(request, 'base/register.html', context)


@login_required(login_url='/login')
def cases(request):

    model = Case.objects.raw('SELECT * FROM base_case')

    context = {
        'datas': model
    }


    return render(request, 'base/cases.html', context)


@login_required(login_url='/login')
def newcase(request):
    form = NewCaseForm()

    if request.method == 'POST':
        print(request.POST.get('crime_category'))
        form = NewCaseForm(request.POST)

        # cg = request.POST.get('crime_category')
        # l = request.POST.get('location')
        # t = request.POST.get('time')
        # sus = request.POST.get('suspects')
        # cs = request.POST.get('case_status')
        # cd = request.POST.get('case_description')

        # my = f"INSERT INTO base_case (crime_category, location, time, suspects, case_status, case_description) VALUES ({cg}, {l}, {t}, {sus}, {cs}, {cd})"

        # data = Case.objects.raw(my)
        # return redirect('cases')
        
        if form.is_valid():
            form.save()
            return redirect('cases')

    context = {
        'form': form
    }

    return render(request, 'base/newcase.html', context)

@login_required(login_url='/login')
def editcase(request, pk):
    # data = Case.objects.get(id=pk)
    my = f"SELECT * FROM base_case WHERE id={pk}"
    data = Case.objects.raw(my)[0]
    #print(data)
    form = NewCaseForm(instance=data)
    if request.method == 'POST':
        form = NewCaseForm(request.POST,instance=data)
        if form.is_valid():
            form.save()
            return redirect('cases')

    context = {
        'form': form,
    }
    return render(request,'base/editcase.html',context)

@login_required(login_url='/login')
def deletecase(request, pk):
    # data = Case.objects.get(id=pk)
    my = f"SELECT * FROM base_case WHERE id={pk}"
    data = Case.objects.raw(my)[0]
    if request.method == 'POST':
        data.delete()
        return redirect('cases')
    return render(request, 'base/delete.html')


def policedetails(request):
    data = User.objects.all()

    context = {
        'datas': data,
    }

    return render(request, 'base/allpolice.html', context)


def searchcases(request):
    data = Case.objects.all()

    if request.method == 'POST':
        p = request.POST.get('query')
        p1 = request.POST.get('suspects')
        p2 = request.POST.get('location')
        p3 = request.POST.get('case_status')
        if p == '' and p1 =='' and p2=='':
            # my = f"SELECT * FROM CriminalDB.base_case WHERE case_status LIKE '%{p3}%'"
            # my = f"SELECT * FROM criminaldb.base_case WHERE case_status IN ({p3})"
            # data = Case.objects.raw(my)
            data = data.filter(case_status__startswith = p3)
            
        elif p== '' and p1 == '' and p3=='':

            # my = f"SELECT * FROM CriminalDB.base_case WHERE location LIKE '%{p2}%'"
            # data = Case.objects.raw(my)
            data = data.filter(location__startswith = p2)

        elif p== ''and p2 == '' and p3=='':

            # my = f"SELECT * FROM CriminalDB.base_case WHERE suspects LIKE '%{p1}%'"
            # data = Case.objects.raw(my)
            data = data.filter(suspects__startswith = p1)

        elif p1== '' and p2=='' and p3=='':

            # my = f"SELECT * FROM CriminalDB.base_case WHERE crime_category LIKE '%{p}%'"
            # data = Case.objects.raw(my)
            data = data.filter(crime_category__startswith = p)

    context = {
        'datas': data
    }

    return render(request, 'base/query.html', context)

@login_required(login_url='/login')
def profile(request):

    return render(request, 'base/profile.html')

@login_required(login_url='/login')
def editprofile(request, pk):
    data = User.objects.get(id=pk)
    form = UserProfileEdit(instance = data)

    if request.method == 'POST':
        form = UserProfileEdit(request.POST,instance=data)
        if form.is_valid():
            form.save()
            return redirect('profile')

    context = {
        'form': form
    }

    return render(request, 'base/editprofile.html', context)


@login_required(login_url='/login')
def criminals(request):

    datas = Criminal.objects.all()
    count_dict = {

    }

    for i in datas:
        count_dict[i.case.crime_category] = 0

    for i in datas:
        count_dict[i.case.crime_category] += 1

    print(count_dict)

    context = {
        'datas': datas
    }

    return render(request, 'base/criminal.html', context)

@login_required(login_url='/login')
def newcriminal(request):

    form = NewCriminal()

    if request.method == 'POST':
        form = NewCriminal(request.POST)
        if form.is_valid():
            form.save()
            return redirect('criminal')

    context = {
        'forms': form,
    }

    return render(request, 'base/newcriminal.html', context)


@login_required(login_url='/login')
def editcriminal(request, pk):
    criminal = Criminal.objects.get(id=pk)
    form = NewCriminal(instance = criminal)

    if request.method == 'POST':
        form = NewCriminal(request.POST,instance=criminal)
        if form.is_valid():
            form.save()
            return redirect('criminal')

    context = {
        'form': form,
    }

    return render(request, 'base/editcriminal.html', context)

@login_required(login_url='/login')
def deletecriminal(request, pk):
    criminal = Criminal.objects.get(id=pk)
    if request.method == 'POST':
        criminal.delete()
        return redirect('criminal')
    return render(request, 'base/deletecriminal.html')


@login_required(login_url='/login')
def viewcase(request, pk):
    data = Case.objects.get(id=pk)
    context = {
        'data': data,
    }

    return render(request, 'base/caseview.html', context)


def statistics(request):
    labels = []
    data = []

    datas = Criminal.objects.all()
    count_dict = {

    }

    for i in datas:
        count_dict[i.case.crime_category] = 0

    for i in datas:
        count_dict[i.case.crime_category] += 1

    for i, j in count_dict.items():
        labels.append(i)
        data.append(int(j))
    

    # queryset = Criminal.objects.order_by('-age')[:5]

    

    # for i in queryset:
    #     labels.append(i.case.crime_category)
    #     data.append(i.age)

    # print(labels)
    # print(data)
    
    context = {
        'labels': labels,
        'data': data,
        'dict': count_dict
    }

    return render(request, 'base/stat.html', context)