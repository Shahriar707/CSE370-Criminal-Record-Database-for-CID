from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    path('login/', views.loginpage, name='login'),
    path('logout/', views.logoutuser, name='logout'),
    path('register/', views.registerpage, name='register'),
    path('profile/', views.profile, name='profile'),
    path('edit-profile/<str:pk>', views.editprofile, name='editprofile'),

    path('cases/', views.cases, name='cases'),
    path('view-case/<str:pk>', views.viewcase, name='viewcase'),
    path('new-case/', views.newcase, name='newcase'),
    path('edit-case/<str:pk>', views.editcase, name='editcase'),
    path('delete-case/<str:pk>', views.deletecase, name='deletecase'),


    path('police-details/', views.policedetails, name='policedetails'),

    path('search-case/', views.searchcases, name='searchcases'),

    path('criminal/', views.criminals, name='criminal'),
    path('new-criminal/', views.newcriminal, name='newcriminal'),
    path('edit-criminal/<str:pk>', views.editcriminal, name='editcriminal'),
    path('delete-criminal/<str:pk>', views.deletecriminal, name='deletecriminal'),


    path('stats/', views.statistics, name='statpage')
]