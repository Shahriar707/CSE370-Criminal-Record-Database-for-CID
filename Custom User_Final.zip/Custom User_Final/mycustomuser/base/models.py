from django.db import models
from django.contrib.auth.models import AbstractUser



# Create your models here.
class Case(models.Model):
    completed = (
        ('Active','Active'),
        ('Completed','Completed')
    )
    crime_category = models.CharField(max_length=50)
    location = models.CharField(max_length=20)
    time = models.TimeField()
    suspects = models.CharField(max_length=200)
    case_status = models.CharField(max_length=20,choices=completed,default='Active')
    case_description = models.TextField(max_length=200)

    def __str__(self):
        return self.crime_category




class User(AbstractUser):
    name = models.CharField(max_length=50, null = True)
    ranks = models.CharField(max_length=50, choices = [('Constable','Constable'),('Sergeant','Sergeant'),('Inspector','Inspector'),('Superintendent of Police','Superintendent of Police')
    ,('Inspector General','Inspector General')], default = 'Constable')
    police_station = models.CharField(max_length=50, null = True)
    phone = models.CharField(max_length=11, null = True)
    area =  models.CharField(max_length=50, null = True)
    house_no = models.CharField(max_length=50, null = True)
    road_no = models.CharField(max_length=50, null = True)
    postal_code = models.IntegerField(null = True)


    REQUIRED_FIELDS = []



class Criminal(models.Model):
    name = models.CharField(max_length=50, null = True)
    nid = models.CharField(max_length=50, null = True)
    birth_mark = models.CharField(max_length=20, null = True)
    case = models.ForeignKey(Case, on_delete=models.CASCADE, null = True)
    age = models.PositiveIntegerField(null = True)

    def __str__(self):
        return self.name
