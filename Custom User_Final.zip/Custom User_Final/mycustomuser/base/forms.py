from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from .models import User, Case, Criminal

# class UserReg(ModelForm):
#     class Meta:
#         model = User
#         fields = ['name', 'username', 'police_station', 'phone', 'area', 'house_no', 'road_no', 'postal_code']

class UserReg(UserCreationForm):
    class Meta:
        model = User
        fields = ['name', 'username', 'ranks','police_station', 'phone', 'area', 'house_no', 'road_no', 'postal_code', 'password1', 'password2']

class NewCaseForm(ModelForm):
    class Meta:
        model = Case
        fields = '__all__'

class UserProfileEdit(ModelForm):
    class Meta:
        model = User
        fields = ['name', 'phone', 'ranks', 'police_station', 'area', 'road_no', 'house_no', 'postal_code']

class NewCriminal(ModelForm):
    class Meta:
        model = Criminal
        fields = '__all__'
